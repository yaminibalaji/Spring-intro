package com.example.TuneIn;

public interface Song {

    String getSongName();

    void setName(String name);

}

